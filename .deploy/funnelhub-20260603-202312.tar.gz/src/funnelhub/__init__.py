"""FunnelHub application package."""
